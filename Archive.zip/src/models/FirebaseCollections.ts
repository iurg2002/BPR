export enum FirebaseCollections {
    Orders = 'orders',
    Users = 'users',
    Operators = 'operators',
    Products = 'products',
    Logs = 'logs',
    Archive = 'archive',
  }
  