export interface GLSAddress {
    street: string;
    city: string;
    postalCode: string;
    country: string;
  }
  